//
//  ViewController.swift
//  reza2010_a2
//
//  Created by Saeid Rezaei (reza2010 - STU : 205812010) on 2/5/23.
//

import UIKit
//var imageF = 0

var numD = 0
var numL = 0
var imageIdx = 0


class ViewController: UIViewController {

    var FruitCollection1 = [Fruit]()
    let CurrentItem : String = "currentIndex"
    private var currentImageIdx = UserDefaults.standard.integer(forKey: "currentIndex")
    
    
    @IBOutlet weak var nDisL: UILabel!
    
    
    @IBOutlet weak var nLikeL: UILabel!
    
    @IBOutlet weak var fruitImg: UIImageView!
    
    
    var fruitCollection  = FruitCollection()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Last run image index is " + String(currentImageIdx))
        
        let existImage = UserDefaults.standard.integer(forKey: "currentIndex")
        imageIdx = existImage
        print("existed image index is \(existImage)")
        
        // Do any additional setup after loading the view.
        if let i = UserDefaults.standard.integer(forKey:
                                                    "currentIndex") as Int? {
            print("Fruits existed with index: \(i)")
            // FruitCollection.setCurrentIndex(to: imageIdx)//restore the fruit
            print(FruitCollection.getFuritname(arrIdex : imageIdx))
            fruitImg.image = UIImage(named :FruitCollection.getFuritname(arrIdex : imageIdx))
            
            
            
        }
    }

    
    @IBAction func test(_ sender: Any) {
        
        numD = numD + 1
        nDisL.text = String(numD)
        
    }
    
    
    @IBAction func BLike2(_ sender: Any) {
        numL = numL + 1
        nLikeL.text = String(numL)
    }
    
    
    
    @IBAction func nxtFruit(_ sender: Any) {
        
        //let existImage = UserDefaults.standard.integer(forKey: "currentIndex") as Int?
                //print("Fruits current with index: \(String(describing: existImage) ?? <#default value#>)")
                nLikeL.text = "0" // reset the counter
                nDisL.text = "0" // reset the counter
                numL = 0
                numD = 0
                imageIdx = imageIdx + 1
                
                if (imageIdx >= 4) {
                    imageIdx = 0
                    
                }
                
                UserDefaults.standard.set(imageIdx, forKey: "currentIndex")
                print ("image index is ---------->>>  " + String(imageIdx))
             //   currentImageIdx = UserDefaults.standard.integer(forKey: "currentIndex")
             //   print("Current image index is " + String(currentImageIdx))
             //   UserDefaults.standard.synchronize()
                //UserDefaults.standard.set(imageIdx, forKey: "currentIndex")
                //let existImage = savedImage.integer(forKey: "currentIndex")
               // print("current image index is \(existImage)")
               // currentImageIdx = existImage
               // print(" current run is -------->>>>" + String(currentImageIdx))
                fruitImg.image = UIImage(named :FruitCollection.getFuritname(arrIdex : imageIdx)) // set the image name based on index
               // savedImage.synchronize()

    }
    
    
    
    
}

