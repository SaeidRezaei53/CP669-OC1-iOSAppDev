//
//  Fruit.swift
//  reza2010_a2
//
//  Created by Saeid Rezaei (STU : 205812010) on 2/8/23.
//

import Foundation
struct Fruit {
    let fruitImageName:String
    let fruitName:String
    var likes = 0
    var disLikes = 0
   
    init(fruitName: String, fruitImageName: String){
        self.fruitImageName = fruitImageName
        self.fruitName = fruitName
    }
}
