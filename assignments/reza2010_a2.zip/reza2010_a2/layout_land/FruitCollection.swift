//
//  FruitCollection.swift
//  reza2010_a2
//
//  Created by Saeid Rezaei on 2/8/23.
//

import Foundation


struct FruitCollection{
    static var collection = [Fruit]() // a collection is an array of fruits
    static var current:Int = 0 // the current fruit in the collection (to be shown in the scene)
   
    init(){ // init is automatically called when you make an instance of the FruitCollection
            // You implement this function
            // Make a Fruit and append it to your FruitCollection
            // repeat as many times as you need, your collection should contain at least four fruits
       
        
        // 1st item
        FruitCollection.collection.append(Fruit(fruitName: "apple", fruitImageName: "apple"))
        print (FruitCollection.collection)
        // 2nd item
        FruitCollection.collection.append(Fruit(fruitName: "banana", fruitImageName: "banana"))
        
        // 3rd item
        FruitCollection.collection.append(Fruit(fruitName: "peach", fruitImageName: "peach"))
        
        // 4th item
        
        FruitCollection.collection.append(Fruit(fruitName: "grapes", fruitImageName: "grapes"))
   
        
    } //init
  
   
    // return the current fruit
    static func currentFruit() -> Fruit {
        let fruit = FruitCollection.collection[FruitCollection.current]
        return fruit
       
    }
   
 
          // return the index of the current fruit
    static func setCurrentIndex(to index: Int) { // you may need this function for
        // relaunching the app
        FruitCollection.current = index
    }
   
                     
 
          // return the index of the current fruit in the collection
    static func getCurrentIndex() -> Int {
        return FruitCollection.current
        }// getCurrentIndex
 
 // other helper functions you may need when relaunching the app
    static func getFuritname(arrIdex : Int) -> String {
        return FruitCollection.collection[arrIdex].fruitImageName

        
    }
} // FruitCollection
