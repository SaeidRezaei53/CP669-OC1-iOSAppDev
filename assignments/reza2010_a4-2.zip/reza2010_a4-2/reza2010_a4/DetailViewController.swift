//
//  DetailViewController.swift
//  reza2010_a4
//
//  Created by Saeid Rezaei on 01/03/2023.
// This view control the object and number of like / dislike
// NOTE: Like and Dislike is button with placeholder , in order to minimize the code I merged two itme into one

import UIKit

// MARK: - DetailViewController

class DetailViewController: UIViewController {

    var fruit: Fruit!

    @IBOutlet weak var fruitImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var likeButton: UIButton!
    @IBOutlet weak var dislikeButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.setData()
    }
   // this function sets image with fruit that is selected in 1st view
    // conver data to UIImage
    private func setData() {
        self.fruitImageView.image = UIImage(data: self.fruit.rawImage)
        self.nameLabel.text = self.fruit.name
        self.likeButton.setTitle("\(self.fruit.likeCount)", for: .normal) // normal type of button state
        self.dislikeButton.setTitle("\(self.fruit.dislikeCount)", for: .normal)
    }

    @IBAction func likeButtonDidTap(_ sender: UIButton?) {
        FruitManager.shared.like(fruitId: self.fruit.id)
        self.setData()
    }

    @IBAction func dislikeButtonDidTap(_ sender: UIButton?) {
        FruitManager.shared.dislike(fruitId: self.fruit.id)
        self.setData()
    }

    @IBAction func nextButtonDidTap(_ sender: UIButton?) {
        let allFruits = FruitManager.shared.allFruits
        let index = allFruits.firstIndex(where: { $0.id == self.fruit.id })! // loop into array when NEXT button pressed
        if index + 1 < allFruits.count {
            self.fruit = allFruits[index + 1]
            
        } else {
          //  sender?.isEnabled = false
            self.fruit = allFruits.first
        }
        self.setData()
        
    }
}
