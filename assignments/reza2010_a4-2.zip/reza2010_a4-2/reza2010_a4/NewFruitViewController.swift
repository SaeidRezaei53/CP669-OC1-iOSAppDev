//
//  NewFruitViewController.swift
//  reza2010_a4
//
//  Created by Saeid Rezaei on 01/03/2023.
// This view control when user wants to add new fruit

import UIKit

protocol NewFruitProtocol: AnyObject {
    func didAddFruit()
}

class NewFruitViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    weak var delegate: NewFruitProtocol!

    @IBOutlet weak var fruitImageView: UIImageView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var saveButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.saveButton.isEnabled = false
       // self.nameTextField.addTarget(self, action: #selector(self.textFieldDidChange), for: .editingChanged)
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.imagePickerDidTap))
        self.fruitImageView.addGestureRecognizer(tap)
    }

    @IBAction func textFieldDidChange(_ sender: UITextField?) {
        self.saveButton.isEnabled = !(sender?.text?.isEmpty ?? true)
    }
    

    @IBAction func saveButtonDidTap(_ sender: UIButton?) {
        let fruit = Fruit(
            name: nameTextField.text!,
            rawImage: self.fruitImageView.image!.pngData()!,
            likeCount: 0,
            dislikeCount: 0)
        FruitManager.shared.add(fruit: fruit)
        self.delegate.didAddFruit()
        self.dismiss(animated: true)
    }

    @IBAction func cancelButtonDidTap(_ sender: UIButton?) {
        self.dismiss(animated: true)
    }

    @objc func imagePickerDidTap() {
        let picker = UIImagePickerController()
        picker.allowsEditing = true
        picker.delegate = self
        present(picker, animated: true)
    }

    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        guard let image = info[.editedImage] as? UIImage else { return }

        self.fruitImageView.image = image
        dismiss(animated: true)
    }
}
