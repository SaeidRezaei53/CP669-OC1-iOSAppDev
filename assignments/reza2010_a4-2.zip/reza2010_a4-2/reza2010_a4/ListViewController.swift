//
//  ListViewController.swift
//  reza2010_a4
//
//  Created by Saeid Rezaei on 01/03/2023.
// This view controller is managing 1st view / page
//

import UIKit

// MARK: - ListViewController

class ListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate , NewFruitProtocol {

    var fruits = [Fruit]()

 
    var selectedFilter = FilterType.all
    var searchQuery = ""
    let cellId = "CellId"

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()

      //  self.tableView.dataSource = self
      //  self.tableView.delegate = self
     //   self.searchBar.searchTextField.addTarget(self, action: #selector(self.didSearch), for: .editingChanged)
      //  self.segmentControl.addTarget(self, action: #selector(self.segmentDidChange), for: .valueChanged)
        print("viewDidLoad")
    }
    // This method runs anytime use get back to this page
    // We want to reload data / fruit after it gets added
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("viewWillAppear")
        self.resetSearch()
        self.getData()
        self.tableView.reloadData()
    }
    // This function sets the search bar to nill and tap page to all
    func resetSearch() {
        self.searchBar.text = ""
        self.searchQuery = ""
        self.selectedFilter = .all
        self.segmentControl.selectedSegmentIndex = 0
    }
  // This function is used to get data from file / array
    func getData() {
        FruitManager.shared.readData()
        self.fruits = FruitManager.shared.allFruits
    }
 // Usage for search and tabs
    private func filteredFruits() -> [Fruit] {
        self.fruits.filter { fruit in
            // this filter is for search bar
            if searchQuery != "" { // user enter text
                return fruit.name.lowercased().contains(searchQuery.lowercased())
            } else {
                return true
            }
        }
        .filter { fruit in
            switch selectedFilter {
            case .all:
                return true
            case .like:
                if fruit.likeCount >= fruit.dislikeCount {
                    return true
                } else {
                    return false
                }
            case .dislike:
                if fruit.dislikeCount > fruit.likeCount {
                    return true
                } else {
                    return false
                }
            }
        }
    }

    func didAddFruit() {
        self.getData()
        self.tableView.reloadData()
    }


    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchQuery = searchText
        self.tableView.reloadData()
        
    }
    // This function calles when + button is pressed to navigate to NewFruitViewController
    @IBAction func addButtonDidTap(_ sender: Any?) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "NewVC") as! NewFruitViewController
        vc.delegate = self
        self.present(vc, animated: true)
    }
    
    @IBAction func segmentDidChange(_ sender: UISegmentedControl?) {
        self.selectedFilter = FilterType(rawValue: sender?.selectedSegmentIndex ?? 0) ?? .all
        self.tableView.reloadData()
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.filteredFruits().count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: self.cellId, for: indexPath) as! FruitTableCell
        let fruit = self.filteredFruits()[indexPath.row]
        cell.nameLabel.text = fruit.name
        cell.fruitImageView.image = UIImage(data: fruit.rawImage) // convert data to image
        cell.likeLabel.text = "\(fruit.likeCount)" // convert Int to String
        cell.dislikeLabel.text = "\(fruit.dislikeCount)"
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "DetailVC") as! DetailViewController
        let fruit = self.filteredFruits()[indexPath.row]
        vc.fruit = fruit // sends data to Detail View
        self.navigationController?.pushViewController(vc, animated: true)
    }
   // call delete
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let fruit = self.filteredFruits()[indexPath.row]
            FruitManager.shared.remove(fruit: fruit) // Json update
            self.getData() // new list
            tableView.deleteRows(at: [indexPath], with: .fade) // Update UI
        }
    }

}

// MARK: - FilterType

enum FilterType: Int {
    case all = 0
    case like = 1
    case dislike = 2
}
