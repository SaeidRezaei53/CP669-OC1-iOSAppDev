//
//  MockData.swift
//  reza2010_a4
//
//  Created by Saeid Rezaei on 01/03/2023.
// Load initial fruits

import UIKit

struct MockData {
    let apple = Fruit(name: "Apple", rawImage: UIImage(named: "apple")!.pngData()!, likeCount: 0, dislikeCount: 0) // pngData return the data instead of actual image
    let banana = Fruit(name: "Banana", rawImage: UIImage(named: "banana")!.pngData()!, likeCount: 0, dislikeCount: 0)
    let grapes = Fruit(name: "Grapes", rawImage: UIImage(named: "grapes")!.pngData()!, likeCount: 0, dislikeCount: 0)
    let peach = Fruit(name: "peach", rawImage: UIImage(named: "peach")!.pngData()!, likeCount: 0, dislikeCount: 0)
   // let strawberry = Fruit(name: "Strawberry", rawImage: UIImage(named: "strawberry")!.pngData()!, likeCount: 0, dislikeCount: 0)
}
