

//
//  Fruit.swift
//  reza2010_a3_v2
//
//  Created by Saeid Rezaei on 2/14/23.
//

import Foundation

class Fruit: Codable {
    var id: UUID
    var name: String
    var rawImage: Data
    var likeCount: Int
    var dislikeCount: Int

    init(id: UUID = UUID(), name: String, rawImage: Data, likeCount: Int, dislikeCount: Int) { // UID is default , optional
        self.id = id
        self.name = name
        self.rawImage = rawImage
        self.likeCount = likeCount
        self.dislikeCount = dislikeCount
    }

    public enum CodingKeys: String, CodingKey {
        case id
        case rawImage
        case name
        case likeCount
        case dislikeCount
    }
}
