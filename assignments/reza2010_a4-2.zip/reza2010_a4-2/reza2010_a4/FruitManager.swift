//
//  FruitManager.swift
//  reza2010_a4
//
//  Created by Saeid Rezaei on 01/03/2023.
//

import Foundation

class FruitManager {

    static let shared = FruitManager() // access to shared outside of FruitManager
    private let fileName = "AppData.json"

    var allFruits: [Fruit] = []
    var fileUrl: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            .appendingPathComponent(self.fileName)
    }
    
    private init() { } // Singleton

    func readData() {
        print(fileUrl)
        if FileManager.default.fileExists(atPath: self.fileUrl.path) {
            do {
                let jsonData = try Data(contentsOf: fileUrl)
                self.allFruits = try JSONDecoder().decode([Fruit].self, from: jsonData)
            } catch {
                print(error.localizedDescription)
            }
        } else {
            let mock = MockData()
            self.allFruits = [mock.apple, mock.banana, mock.grapes, mock.peach]
            self.writeData()
        }
    }

    func writeData() {
        do {
            let data = try JSONEncoder().encode(self.allFruits)
            try data.write(to: self.fileUrl)
        } catch {
            print(error.localizedDescription)
        }
    }

    func add(fruit: Fruit) {
        self.allFruits.append(fruit)
        self.writeData()
    }

    func remove(fruit: Fruit) {
        self.allFruits.removeAll { item in
            item.id == fruit.id
        }
        self.writeData()
    }

    func like(fruitId id: UUID) {
        self.allFruits.first(where: { $0.id == id })?.likeCount += 1 // find the 1st element that has same ID, then quite from loop
        self.writeData()
    }

    func dislike(fruitId id: UUID) {
        self.allFruits.first(where: { $0.id == id })?.dislikeCount += 1
        self.writeData()
    }
}
