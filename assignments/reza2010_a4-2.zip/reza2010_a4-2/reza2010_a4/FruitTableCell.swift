//
//  FruitTableCell.swift
//  reza2010_a4
//
//  Created by Saeid Rezaei on 01/03/2023.
//

import UIKit

class FruitTableCell: UITableViewCell {
    @IBOutlet weak var fruitImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var likeLabel: UILabel!
    @IBOutlet weak var dislikeLabel: UILabel!
}
