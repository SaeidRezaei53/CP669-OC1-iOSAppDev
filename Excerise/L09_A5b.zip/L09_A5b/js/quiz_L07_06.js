// JavaScript Document


(function() {
	'use strict';
  var myQuestions = [
    {
	number: "Question 1 of 6",
	question: "In UIView, the units of the coordinate system are",
	answers: {
			a: "points",
			b: "pixels",
      },
	correctAnswer: "a",
	},
	{
	number: "Question 2 of 6",
	question: "In UIView, the point (0,0) is the",
	answers: {
			a: "upper-left corner",
			b: "lower-right corner",
      },
	correctAnswer: "a",
	},
	{
	number: "Question 3 of 6",
	question: "To draw an image, you call the method",
	answers: {
			a: "draw",
			b: "viewNeedsDisplay",
      },
	correctAnswer: "b",
	},
	{
	number: "Question 4 of 6",
	question: "When the frame of a UIView is changed, it is not automatically redrawn. The property you have to set to handle this case is",
	answers: {
			a: "redrawMode",
			b: "contentMode",
			c: "displayMode",
      },
	correctAnswer: "b",
	},
	{
	number: "Question 5 of 6",
	question: "With the timer, the value  “withTimeInterval: 5.0” means",
	answers: {
			a: "The action is started immediately, then repeated every 5 seconds",
			b: "Nothing happens in 5 seconds, then the action is repeated every 5 second",
			
      },
	correctAnswer: "b",
	},
	{
	number: "Question 6 of 6",
	question: "The UIPanGestureRecognizer is used for ",
	answers: {
			a: "dragging the view",
			b: "magnify the view",
			c: "flatten the view",
			
      },
	correctAnswer: "a",
	},
  ];
	
  function buildQuiz() {
	    
	 
    // we'll need a place to store the HTML output
    var output = [];

    // for each question...
    myQuestions.forEach((currentQuestion, questionNumber) => {
      // we'll want to store the list of answer choices
      var answers = [];

	var letter = currentQuestion.answers[letter];
		
      // and for each available answer...
      for (letter in currentQuestion.answers) {
        // ...add an HTML radio button
        answers.push(
          `<label>
			<div class="answers-input">
			<input type="radio" name="question${questionNumber}" value="${letter}" id="${questionNumber}${letter}" onClick="resetButtons(), hideFeedback()">
			</div>
         	<div class="answers-input"><strong>${letter}.</strong> ${currentQuestion.answers[letter]}</div>
          
           </label>`
        );
      }

	
	// add this question and its answers to the output
      output.push(
        `<div class="slide">
			<div class="number" id="${questionNumber}"> ${currentQuestion.number}</div>
           <div class="question"> ${currentQuestion.question} </div>
           <div class="answers"> ${answers.join("")} </div>
	    </div>`
      );	
      
    });

    // finally combine our output list into one string of HTML and put it on the page
    quizContainer.innerHTML = output.join("");
  }
	
  function showSlide(n) {	
	  

    slides[currentSlide].classList.remove("active-slide");
    slides[n].classList.add("active-slide");
    currentSlide = n;
    if (currentSlide === 0) {
      previousButton.style.display = "none";
    } else {
      previousButton.style.display = "inline-block";
    }
    
    if (currentSlide === slides.length - 1) {
      nextButton.style.display = "none";

      submitAnswerButton.style.display = "inline-block";

    } else {
      nextButton.style.display = "inline-block";
    		
    }
  }

  function showNextSlide() {
    showSlide(currentSlide + 1);
	
	 		// Change aria-label
		  nextButton.setAttribute('aria-label', 'Next question. Return to previous landmark to read current question.');
  		
 }

  function showPreviousSlide() {
    showSlide(currentSlide - 1);
  }

	function submitAnswer() { 
	var answerContainers = quizContainer.querySelectorAll(".answers");
	 var answerContainer = answerContainers[currentSlide];
      var selector = `input[name=question${currentSlide}]:checked`;
      var userAnswer = (answerContainer.querySelector(selector) || {}).value;

      // if answer is correct
      if ((userAnswer === myQuestions[currentSlide].correctAnswer)) {
       
	 // color the answers blue
        answerContainers[currentSlide].style.color = "#6D5162";
		 if (currentSlide ===5) {
			 submitAnswerButton.setAttribute('aria-label', 'Correct! This is the last question. You may review previous questions using the previous question and next question buttons. Or, you may continue with the lesson below the quiz.');
			 feedbackContainer.innerHTML ="Correct!";
		}
        else {
			submitAnswerButton.setAttribute('aria-label', 'Correct! Go to next question button to go to next question');
			 feedbackContainer.innerHTML ="Correct!";
		}
			 
      } else {
        // if answer is wrong or blank
        // color the answers red
        answerContainers[currentSlide].style.color = "red";
		 submitAnswerButton.setAttribute('aria-label', 'Incorrect. You may go up to try again, or go to next question button to go to next question');
		  feedbackContainer.innerHTML ="Incorrect. You may try again.";
      }
		
	nextButton.disabled = false;
	
	
	}
	
  	var quizContainer = document.getElementById("quiz");
  	var resultsContainer = document.getElementById("results");
	var feedbackContainer = document.getElementById("feedback");
  // display quiz right away
  buildQuiz();

	var submitAnswerButton = document.getElementById("submitAnswer");
  	var previousButton = document.getElementById("previous");
	var nextButton = document.getElementById("next");
	var slides = document.querySelectorAll(".slide");
  	var currentSlide = 0;



  showSlide(0);

  // on submit, show results
	submitAnswerButton.addEventListener("click", submitAnswer);
  	previousButton.addEventListener("click", showPreviousSlide);
  	nextButton.addEventListener("click", showNextSlide);
})();


function resetButtons() {
	var nextButton = document.getElementById("next");
	var submitAnswerButton = document.getElementById("submitAnswer");
	  // Change aria-label
	nextButton.setAttribute('aria-label', 'Next question');
	submitAnswerButton.disabled = false;
	submitAnswerButton.setAttribute('aria-label', 'submit answer');
	
	  } 

function hideFeedback() {
	var feedbackContainer = document.getElementById("feedback");
	feedbackContainer.innerHTML =" ";	
}

