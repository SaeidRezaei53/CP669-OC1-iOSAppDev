//
//  ViewController.swift
//  myClickCount_L1
//  Saeid Rezaei (rezae2010)
//  Created by admin user on 2023-01-16.
//

import UIKit
var num = 0

class ViewController: UIViewController {
    @IBOutlet weak var Label: UILabel!
    
    @IBAction func PressMe(_ sender: Any) {
        num = num + 1
        Label.text = "Number of clicks :" + String(num)
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}
