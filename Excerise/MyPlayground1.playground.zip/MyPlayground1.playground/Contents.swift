import UIKit

var greeting = "Hello, playground"
class Person {
    private var firstName: String?
    private var lastName: String?
    private var  birthYear : Int?

    private var  ID = UUID().hashValue // unique for each person
    private var children : [Person]? // children of the person

    init(fName: String, lName: String, bYear: Int, children: [Person]?){
        self.firstName = fName
        self.lastName = lName
        self.birthYear = bYear

        if children != nil {

                self.children = children
          }   // init

     }

    func getFirstName() -> String? {
        return self.firstName
    }

    func getLastName() -> String? {
        return self.lastName
    }

    func getBirthYear() -> Int? {
        return self.birthYear
    }

    func getPersonalInfo() -> String {
       return (self.firstName ?? "no first name , ") + " " + (self.lastName ?? " no last name, ") + " (ID = " + (String(self.ID)) + ")"
    }

    func isSamePersonAs(other: Person?) -> Bool { // return true if self is the same person as other

        // you implement this function
        if (other?.firstName  == self.firstName) && (other?.lastName  == self.lastName){
            return true
        } else { return false}
    }

    func isChildOf(per: Person?) -> Bool { // return true if self is a child of per

     // you implement this function
        if self.children != nil  {
            return true
        }
        else {return false}
    }

} // Person

extension Person{ // exercise to extend a class with a function
    func setBirthYear(newYear : Int){ // change the birth year of the person
      //print ("You are yong")
                 // you implement this function

                // print a congratulation message if the person gets younger
        if self.birthYear! < newYear {
            print ("congratulation you are getting younger")
            print ("New birth year of " + getPersonalInfo() + ":" + String (newYear))
        }
        else {
            print ("Change birth year of " + getPersonalInfo() )
            print (getPersonalInfo() + ":" + String(newYear) )
            print ("New birth year of " + getPersonalInfo() + ":" + String (newYear))
        }
                // print the new birth year of the person

    }
}

 // test your implementation with the code below

let Chris = Person(fName: "Chris", lName: "Apple", bYear: 2010, children: nil)

let Danie = Person(fName: "Danie", lName: "Apple", bYear: 2012, children: nil)

let childrenSet1 = [Chris, Danie]

let childrenSet2 = [Danie]

let a = Person(fName: "John", lName: "Apple", bYear: 1980, children: childrenSet1 )

let b = Person(fName: "Lisa", lName: "Apple", bYear: 1982, children: nil)

let c = Person(fName: "Michelle", lName: "Apple", bYear: 1983, children: childrenSet2)

let d = Person(fName: "Michelle", lName: "Apple", bYear: 1982, children: nil)

if b.isSamePersonAs(other: c) { // we can test this loop with different persons

    let theInfo = (b.getPersonalInfo() + " is the same person as " + c.getPersonalInfo() )

    print(theInfo)

} else {

    let theInfo = (b.getPersonalInfo() + " is the not same person as " + c.getPersonalInfo() )

    print(theInfo)

}

if Chris.isChildOf(per: a) { // we can test this loop with different persons

    print ((Chris.getPersonalInfo()) + " is child of " + (a.getPersonalInfo()))

} else {

    print ((Chris.getPersonalInfo()) + " is not child of " + (a.getPersonalInfo()))

}

if Chris.isChildOf(per: b) { // we can test this loop with different persons

    print ((Chris.getPersonalInfo()) + " is child of " + (b.getPersonalInfo()))

} else {

    print ((Chris.getPersonalInfo()) + " is not child of " + (b.getPersonalInfo()))

}

c.setBirthYear(newYear: 1984)

a.setBirthYear(newYear: 1979)

